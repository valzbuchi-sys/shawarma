// BUCHIS SHAWARMA ORDER SYSTEM


let cart = [];




// CART BUTTON

const cartBtn = document.getElementById("cartBtn");

const cartBox = document.getElementById("cartBox");



cartBtn.addEventListener("click",()=>{

cartBox.classList.toggle("active");

});








// SCROLL TO MENU

function scrollToMenu(){

document.getElementById("menu").scrollIntoView({

behavior:"smooth"

});

}








// ADD TO CART


function addToCart(name,price){



let existing = cart.find(item=>item.name===name);



if(existing){


existing.quantity++;


}

else{


cart.push({

name:name,

price:price,

quantity:1


});


}



updateCart();


alert(name + " added to cart");


}









// UPDATE CART


function updateCart(){


let cartItems=document.getElementById("cartItems");

let total=document.getElementById("total");

let cartCount=document.getElementById("cartCount");



cartItems.innerHTML="";



let totalAmount=0;

let count=0;




if(cart.length===0){


cartItems.innerHTML="<p>Your cart is empty</p>";

}



cart.forEach((item,index)=>{


totalAmount += item.price * item.quantity;


count += item.quantity;



cartItems.innerHTML += `


<div class="cart-item">


<h4>${item.name}</h4>


<p>
₦${item.price.toLocaleString()} x ${item.quantity}
</p>



<button onclick="increase(${index})">
+
</button>


<button onclick="decrease(${index})">
-
</button>


<button onclick="removeItem(${index})">
Remove
</button>


</div>


`;



});




total.innerHTML=totalAmount.toLocaleString();


cartCount.innerHTML=count;



}









// INCREASE ITEM


function increase(index){


cart[index].quantity++;


updateCart();


}







// DECREASE ITEM


function decrease(index){


if(cart[index].quantity>1){


cart[index].quantity--;


}

else{


cart.splice(index,1);


}



updateCart();


}









// REMOVE ITEM


function removeItem(index){


cart.splice(index,1);


updateCart();


}










// OPEN CHECKOUT


function openCheckout(){



if(cart.length===0){


alert("Your cart is empty");


return;


}



document.getElementById("checkout").style.display="flex";


}






// CLOSE CHECKOUT


function closeCheckout(){


document.getElementById("checkout").style.display="none";


}








// SHOW PAYMENT DETAILS


function showPayment(){


document.getElementById("paymentInfo").style.display="block";


}









// PLACE ORDER


function placeOrder(){



let name=document.getElementById("customerName").value;


let phone=document.getElementById("phone").value;


let address=document.getElementById("address").value;




if(name==="" || phone==="" || address===""){


alert("Please fill your delivery details");


return;


}







let total=document.getElementById("total").innerHTML;



let items=cart.map(item=>{


return item.name + " x " + item.quantity;


}).join(", ");







let orderNumber="BUC"+Math.floor(Math.random()*100000);






let order={



orderNumber:orderNumber,


name:name,


phone:phone,


address:address,


items:items,


total:total,


date:new Date().toLocaleString()



};








// SAVE ORDER FOR ADMIN



let orders=JSON.parse(localStorage.getItem("orders")) || [];



orders.push(order);



localStorage.setItem(

"orders",

JSON.stringify(orders)

);









// WHATSAPP MESSAGE



let message=`

Hello Buchis Shawarma 🌯


New Order Received


Order Number:
${orderNumber}



Customer:
${name}



Phone:
${phone}



Address:
${address}



Items:
${items}



Total:
₦${total}



Please prepare this order.

`;








// BUCHIS WHATSAPP NUMBER


let whatsappNumber="2348039632856";





let whatsappURL=

"https://wa.me/"

+ whatsappNumber +

"?text="

+

encodeURIComponent(message);





window.open(

whatsappURL,

"_blank"

);







alert(

"Thank you "+name+"! Your order has been received."

);







cart=[];


updateCart();


closeCheckout();




}